export interface userDTO{
    nombre: String;
    apellido: String;
    edad: number | null
    email?: String;
    contra?: String;
    contra2?: String;
   // lenguajes?: Language[];
}

//export interface Language{
    //name: String;
    //code: String;
//}