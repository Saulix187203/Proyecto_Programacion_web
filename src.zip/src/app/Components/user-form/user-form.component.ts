import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { userDTO } from '../../interfaces/userDTO';

@Component({
  selector: 'app-user-form',
  imports: [
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    FormsModule
  ],
  templateUrl: './user-form.component.html',
  styleUrl: './user-form.component.css'
})
export class UserFormComponent {

  userOBJ: userDTO = {
    nombre: '',
    apellido: '',
    edad: 0,
    email: '',
    contra: '',
    contra2: ''
  };


  @Output() userSumbit = new EventEmitter<userDTO>();
  subirForm() {
    const { nombre, apellido, edad, email, contra, contra2 } = this.userOBJ;

    if (this.userOBJ.nombre && this.userOBJ.apellido && this.userOBJ.edad && this.userOBJ.contra && this.userOBJ.contra2 !== null) {
      this.userSumbit.emit({
        nombre: nombre,
        apellido: apellido,
        edad: edad,
        email: email,
        contra: contra,
        contra2: contra2
      });
      this.userOBJ.nombre = "";
      this.userOBJ.apellido = "";
      this.userOBJ.edad = null;
      this.userOBJ.email = "";
      this.userOBJ.contra = "";
      this.userOBJ.contra2 = "";
    }
  }
}
